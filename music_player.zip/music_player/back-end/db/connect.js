const mongoose = require('mongoose');

mongoose.connect('mongodb+srv://simar123:simar123@cluster0.vkh4f.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',{ useNewUrlParser: true },
{poolSize:5}, (err=>{
    if(err){
        console.log('Problem in DB Connection');
    }
    else{
        console.log('DB Connection Created....');
    }
}));
module.exports = mongoose;